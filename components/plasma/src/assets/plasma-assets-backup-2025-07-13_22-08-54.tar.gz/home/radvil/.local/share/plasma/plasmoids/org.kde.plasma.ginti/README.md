# Ginti - Desktop Indicator for Plasma 6
A simple applet to display current desktop status.

## Screenshots
![Screenshot_20240414_020220](https://github.com/dhruv8sh/plasma6-desktopindicator-gnome/assets/67322047/9fda3f30-0191-43aa-af07-1b503392b1c3)
![Screenshot_20240414_020236](https://github.com/dhruv8sh/plasma6-desktopindicator-gnome/assets/67322047/02efc22e-25bd-4caf-bf04-aa69fccc0468)

This is an extension of a pre-existing applet by me.<br/>
Please check it out [here](https://github.com/dhruv8sh/plasma6-desktop-indicator) as well if you liked this one.
